# csvtodocx
A file coverter for mah friend
# steps:
  open up cmd
  
  cd to this file's location
  
  type in ./env/Scripts/activate
  
  type python csvtodocx.py
