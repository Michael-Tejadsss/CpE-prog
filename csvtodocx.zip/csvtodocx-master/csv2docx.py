from docx import Document
from docx.shared import Inches
import csv
from docx.enum.section import WD_ORIENT
from docx.enum.section import WD_SECTION
from docx.shared import Pt

data =[]

document = Document()


def change_orientation():
    current_section = document.sections[-1]
    new_width, new_height = current_section.page_height, current_section.page_width
    new_section = document.add_section(WD_SECTION.NEW_PAGE)
    new_section.orientation = WD_ORIENT.LANDSCAPE
    new_section.page_width = new_width
    new_section.page_height = new_height

    return new_section

change_orientation()

with open('data.csv') as fileko:
    reader = csv.reader(fileko)
    for row in reader:
        data.append(row)

style = document.styles['Normal']
font = style.font
font.name = 'Arial Narrow'
font.size = Pt(11)

document.add_picture('header.PNG')

table = document.add_table(rows=1, cols=13)
table.style = 'TableGrid'
hdr_cells = table.rows[0].cells
hdr_cells[0].text = 'household #'
hdr_cells[1].text = 'full name'
hdr_cells[2].text = 'last name'
hdr_cells[3].text = 'first name'
hdr_cells[4].text = 'middle name'
hdr_cells[5].text = 'name extension'
hdr_cells[6].text = 'address'
hdr_cells[7].text = 'birth place'
hdr_cells[8].text = 'birthdate'
hdr_cells[9].text = 'gender'
hdr_cells[10].text = 'civil status'
hdr_cells[11].text = 'citizenship'
hdr_cells[12].text = 'occupation'
rownum=0
for c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13 in data:
    row_cells = table.add_row().cells
    if rownum != 0:
        row_cells[0].text = c1
        row_cells[1].text = c2
        row_cells[2].text = c3
        row_cells[3].text = c4
        row_cells[4].text = c5
        row_cells[5].text = c6
        row_cells[6].text = c7
        row_cells[7].text = c8
        row_cells[8].text = c9
        row_cells[9].text = c10
        row_cells[10].text = c11
        row_cells[11].text = c12
        row_cells[12].text = c13
        print(f'Adding row {rownum}')
    rownum += 1

document.add_page_break()

#changing the page margins
sections = document.sections
for section in sections:
    section.top_margin = Inches(0.5)
    section.bottom_margin = Inches(0.5)
    section.left_margin = Inches(0.625)
    section.right_margin = Inches(0.625)

document.save('census.docx')